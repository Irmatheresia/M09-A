import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase1/models.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fab_circular_menu/fab_circular_menu.dart';

class MyHome extends StatefulWidget {
  const MyHome({super.key});

  @override
  State<MyHome> createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  List<EventModel> details = [];

  Future testData() async {
    await Firebase.initializeApp();
    print("init Done");
    FirebaseFirestore db = await FirebaseFirestore.instance;
    print(('init Firestore Done'));
    var data = await db.collection('event_id').get().then((event) {
      for (var doc in event.docs) {
        print("${doc.id}=> ${doc.data()}");
      }
    });
  }

  Future readData() async {
    await Firebase.initializeApp();
    FirebaseFirestore db = await FirebaseFirestore.instance;
    var data = await db.collection('event_id').get();
    setState(() {
      details =
          data.docs.map((doc) => EventModel.fromDocSnapshot((doc))).toList();
    });
  }

  @override
  void initState() {
    readData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    testData();
    return Scaffold(
      appBar: AppBar(title: Text("Cloud Firestore")),
      body: ListView.builder(
        itemCount: details.length,
        itemBuilder: (context, position) {
          return CheckboxListTile(
            onChanged: (bool? value) {},
            value: details[position].is_like,
            title: Text(details[position].judul),
            subtitle: Text("${details[position].keterangan}" +
                "\nHari : ${details[position].tanggal}" +
                "\nPembicara : ${details[position].pembicara}"),
            isThreeLine: true,
          );
        },
      ),
      floatingActionButton: FabCircularMenu(children: <Widget>[
        IconButton(icon: Icon(Icons.add), onPressed: () {}),
        IconButton(icon: Icon(Icons.remove), onPressed: () {}),
      ]),
    );
  }
}
