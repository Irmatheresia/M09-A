import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'getuser.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      // options: DefaultFirebaseOptions.currentPlatform,
      );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  FirebaseFirestore db = FirebaseFirestore.instance;
  String _counter2 = "-";

  ///FirebaseFirestore firestore = FirebaseFirestore.instance;

  void addData() {
    // Create a new user with a first and last name
    final user = <String, dynamic>{
      "first": "Ada",
      "last": "Lovelace",
      "born": 1815
    };

    GetUserName getUser(String s) {
      return GetUserName(documentId: s);
    }

// Create a new user with a first and last name
    final user2 = <String, dynamic>{
      "first": "Alan",
      "middle": "Mathison",
      "last": "Turing",
      "born": 1912
    };
    FirebaseFirestore db = FirebaseFirestore.instance;
// Add a new document with a generated ID
    db.collection("users").add(user).then((DocumentReference doc) =>
        print('DocumentSnapshot added with ID: ${doc.id}'));

    // Add a new document with a generated ID
    db.collection("users").add(user).then((DocumentReference doc) =>
        print('DocumentSnapshot added with ID: ${doc.id}'));
  }

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  Stream<QuerySnapshot<Object?>> ambilData() {
    return FirebaseFirestore.instance.collection('user').snapshots();
  }

  @override
  Widget build(BuildContext context) {
    //CollectionReference users = db.collection('user');
    //List<Map<String, dynamic>> dataUser = getData();
    return StreamBuilder<QuerySnapshot>(
      stream: ambilData(),
      builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Text('Something went wrong');
        }

        if (snapshot.connectionState == ConnectionState.waiting) {
          return Text("Loading");
        }
        print("lewat");
        List<QueryDocumentSnapshot> tmp = snapshot.data!.docs;

        return ListView.builder(
            itemCount: tmp.length,
            itemBuilder: ((context, index) {
              var rute = MaterialPageRoute(
                  builder: (BuildContext context) =>
                      GetUserName(documentId: "${tmp[index].id}"));
              var dt = tmp[index].data() as Map<String, dynamic>;
              return TextButton(
                  onPressed: () {
                    Navigator.push(context, rute);
                  },
                  child: Text("${dt["name"]}"));
            }));
      },
    );
  }
}
